#include <ESP8266WiFi.h>
#include <PubSubClient.h>

// ─── WiFi & MQTT ────────────────────────────────
const char* ssid        = "project";
const char* password    = "12345678";
const char* mqtt_broker = "broker.hivemq.com";
const int   mqtt_port   = 1883;
const char* topic       = "esp/led/control";

// ─── Engine Lock LED ────────────────────────────
#define LED_PIN 2    // GPIO2 — Engine Lock Indicator (inverted logic)

WiFiClient espClient;
PubSubClient client(espClient);

// ─── MQTT Message Callback ──────────────────────
void callback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  Serial.print("Command Received: ");
  Serial.println(message);

  if (message == "SAFE") {
    digitalWrite(LED_PIN, HIGH);   // ✅ HIGH = OFF on GPIO2 (inverted)
    Serial.println(">> Engine ALLOWED — LED OFF ✅");

  } else if (message == "LOCK") {
    digitalWrite(LED_PIN, LOW);    // ❌ LOW = ON on GPIO2 (inverted)
    Serial.println(">> Engine LOCKED — LED ON 🔒");
  }
}

// ─── MQTT Connect & Reconnect ───────────────────
void connectMQTT() {
  while (!client.connected()) {
    Serial.print("Connecting to MQTT...");
    String clientId = "ESP8266-Slave-" + String(random(0xffff), HEX);
    if (client.connect(clientId.c_str())) {
      Serial.println("Connected!");
      client.subscribe(topic);
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(3000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);    // ✅ Start LOCKED by default (safe boot state)

  // ─── Connect WiFi ─────────────────────────────
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Connected! IP: " + WiFi.localIP().toString());

  // ─── Setup MQTT ───────────────────────────────
  client.setServer(mqtt_broker, mqtt_port);
  client.setCallback(callback);
  connectMQTT();
}

void loop() {
  if (!client.connected()) {
    connectMQTT();
  }
  client.loop();
}