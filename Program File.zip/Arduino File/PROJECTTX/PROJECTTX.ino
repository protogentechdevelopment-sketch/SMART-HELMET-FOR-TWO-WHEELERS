#include <Wire.h>
#include <HardwareSerial.h>
#include <WiFi.h>
#include <PubSubClient.h>

// ─── WiFi & MQTT ────────────────────────────────
const char* ssid        = "project";
const char* password    = "12345678";
const char* mqtt_broker = "broker.hivemq.com";
const int   mqtt_port   = 1883;
const char* topic       = "esp/led/control";

// ─── MPU6050 ────────────────────────────────────
#define MPU6050_ADDR    0x68
#define SDA_PIN         6
#define SCL_PIN         7
#define GYRO_SCALE      131.0

#define SAFE_MAX         0.5
#define ACTIVE_MAX       10.0
#define ACCIDENT_MIN     10.0
#define CONFIRM_COUNT    3

// ─── ISD1820 ────────────────────────────────────
#define ISD1820_PLAY     3

// ─── KY-004 Response Button ─────────────────────
#define RESPONSE_BTN     1

// ─── GSM UART ───────────────────────────────────
#define GSM_TX_PIN       4
#define GSM_RX_PIN       5
#define GSM_BAUD         9600

// ─── Alert Numbers ──────────────────────────────
#define PERSON1         "6369419865"
#define PERSON2         "9384033126"

#define WAIT_TIME_MS    10000

// ─── Sensor & Button Pins ───────────────────────
#define ALCOHOL_PIN   0    // MQ-135 Analog → GPIO0 (ADC)
#define IR_PIN        2    // IR Sensor Digital → GPIO2

// ─── Alcohol Threshold ──────────────────────────
#define ALCOHOL_THRESHOLD  699

// ─── Gyro Variables ─────────────────────────────
int16_t gyro_x_raw, gyro_y_raw, gyro_z_raw;
float   gyro_x, gyro_y, gyro_z;
int     accidentCounter = 0;
bool    accidentFired   = false;

// ─── MQTT Variables ─────────────────────────────
String lastCommand = "";

HardwareSerial gsmSerial(1);
WiFiClient espClient;
PubSubClient client(espClient);

// ════════════════════════════════════════════════
//   GSM
// ════════════════════════════════════════════════

void GSM_SendCommand(String cmd, int waitMs = 1000)
{
  gsmSerial.println(cmd);
  delay(waitMs);
  while (gsmSerial.available()) {
    Serial.write(gsmSerial.read());
  }
}

void GSM_Init()
{
  Serial.println(">> Initializing GSM...");
  delay(3000);

  GSM_SendCommand("AT",        1000);
  GSM_SendCommand("AT",        1000);
  GSM_SendCommand("ATE0",      1000);
  GSM_SendCommand("ATE0",      1000);
  GSM_SendCommand("AT+CMGF=1", 1000);
  GSM_SendCommand("AT+CREG?",  1000);
  GSM_SendCommand("AT+CSQ",    1000);

  Serial.println(">> GSM Ready!");
}

void GSM_MakeCall(String number)
{
  Serial.println(">> Calling: " + number);
  delay(500);
  while (gsmSerial.available()) gsmSerial.read();
  GSM_SendCommand("ATD" + number + ";", 25000);
  GSM_SendCommand("ATH", 2000);
  Serial.println(">> Call Done: " + number);
  delay(3000);
}

void GSM_SendSMS(String number, String message)
{
  Serial.println(">> Sending SMS to: " + number);
  GSM_SendCommand("AT+CMGF=1", 1000);
  delay(300);
  while (gsmSerial.available()) gsmSerial.read();

  gsmSerial.println("AT+CMGS=\"" + number + "\"");
  Serial.println("AT+CMGS=\"" + number + "\"");

  bool gotPrompt = false;
  unsigned long t = millis();
  while (millis() - t < 5000)
  {
    if (gsmSerial.available()) {
      char c = gsmSerial.read();
      Serial.write(c);
      if (c == '>') {
        gotPrompt = true;
        break;
      }
    }
  }

  if (!gotPrompt) {
    Serial.println(">> ERROR: No > prompt!");
    gsmSerial.write(0x1B);
    delay(500);
    return;
  }

  delay(200);
  gsmSerial.print(message);
  delay(500);
  gsmSerial.write(0x1A);
  delay(7000);
  while (gsmSerial.available()) {
    Serial.write(gsmSerial.read());
  }

  Serial.println(">> SMS Sent: " + number);
}

void SendAlertToBoth()
{
  String smsMsg = "ACCIDENT DETECTED! Helmet wearer may need help. Location: https://maps.google.com/?q=11.127195,77.199837";

  Serial.println("════ Alerting Person 1 ════");
  GSM_MakeCall(PERSON1);
  GSM_SendSMS(PERSON1, smsMsg);
  delay(5000);

  Serial.println("════ Alerting Person 2 ════");
  GSM_MakeCall(PERSON2);
  GSM_SendSMS(PERSON2, smsMsg);

  Serial.println(">> All Alerts Sent ✅");
}

// ════════════════════════════════════════════════
//   MPU6050
// ════════════════════════════════════════════════

void MPU6050_Init()
{
  Serial.println("Initializing MPU6050...");
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x6B);
  Wire.write(0x00);
  Wire.endTransmission(true);

  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x1B);
  Wire.write(0x00);
  Wire.endTransmission(true);
  Serial.println("MPU6050 Ready!");
}

void MPU6050_Read_Gyro()
{
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x43);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU6050_ADDR, 6, true);

  gyro_x_raw = (Wire.read() << 8 | Wire.read());
  gyro_y_raw = (Wire.read() << 8 | Wire.read());
  gyro_z_raw = (Wire.read() << 8 | Wire.read());

  gyro_x = gyro_x_raw / GYRO_SCALE;
  gyro_y = gyro_y_raw / GYRO_SCALE;
  gyro_z = gyro_z_raw / GYRO_SCALE;
}

bool IsSafeStationary()
{
  return (abs(gyro_x) <= SAFE_MAX &&
          abs(gyro_y) <= SAFE_MAX &&
          abs(gyro_z) <= SAFE_MAX);
}

bool IsAccidentPattern()
{
  return (abs(gyro_x) > ACCIDENT_MIN ||
          abs(gyro_y) > ACCIDENT_MIN ||
          abs(gyro_z) > ACCIDENT_MIN);
}

// ════════════════════════════════════════════════
//   ISD1820
// ════════════════════════════════════════════════

void ISD1820_Play()
{
  digitalWrite(ISD1820_PLAY, HIGH);
  delay(200);
  digitalWrite(ISD1820_PLAY, LOW);
  Serial.println(">> ISD1820 Playing Voice Message...");
  delay(3000);
}

// ════════════════════════════════════════════════
//   HANDLE IMPACT
// ════════════════════════════════════════════════

void HandleImpact()
{
  accidentFired   = true;
  accidentCounter = 0;

  Serial.println("╔══════════════════════════════╗");
  Serial.println("║   ACCIDENT PATTERN DETECTED!  ║");
  Serial.println("╚══════════════════════════════╝");
  Serial.print(">> Gyro X: "); Serial.print(gyro_x, 2);
  Serial.print("  Y: ");       Serial.print(gyro_y, 2);
  Serial.print("  Z: ");       Serial.println(gyro_z, 2);

  Serial.println(">> STEP 1: Playing voice alert...");
  ISD1820_Play();

  Serial.println(">> STEP 2: Waiting for user response...");
  Serial.println(">> Press button within 10 seconds if SAFE!");
  Serial.flush();
  Serial.end();

  pinMode(RESPONSE_BTN, INPUT_PULLUP);

  unsigned long startTime = millis();
  bool userResponded      = false;

  while (millis() - startTime < WAIT_TIME_MS)
  {
    if (digitalRead(RESPONSE_BTN) == LOW) {
      userResponded = true;
      delay(300);
      break;
    }
    delay(50);
  }

  Serial.begin(115200);

  if (userResponded)
  {
    Serial.println("══════════════════════════════");
    Serial.println(">> STEP 3: Button Pressed ✅");
    Serial.println(">> USER SAFE — No Alert Sent!");
    Serial.println("══════════════════════════════");
  }
  else
  {
    Serial.println("══════════════════════════════");
    Serial.println(">> STEP 3: No Response ❌");
    Serial.println(">> ACCIDENT CONFIRMED!");
    Serial.println(">> STEP 4: Sending GSM Alerts...");
    Serial.println("══════════════════════════════");
    SendAlertToBoth();
  }

  Serial.println(">> System resuming monitoring...");
  accidentFired   = false;
  accidentCounter = 0;
}

// ════════════════════════════════════════════════
//   MQTT
// ════════════════════════════════════════════════

void connectMQTT()
{
  while (!client.connected()) {
    Serial.print("Connecting to MQTT...");
    String clientId = "ESP32C3-Master-" + String(random(0xffff), HEX);
    if (client.connect(clientId.c_str())) {
      Serial.println("Connected!");
    } else {
      Serial.print("Failed, rc=");
      Serial.println(client.state());
      delay(3000);
    }
  }
}

// ════════════════════════════════════════════════
//   SETUP
// ════════════════════════════════════════════════

void setup()
{
  Serial.begin(115200);

  pinMode(ISD1820_PLAY, OUTPUT);
  digitalWrite(ISD1820_PLAY, LOW);
  pinMode(RESPONSE_BTN, INPUT_PULLUP);
  pinMode(IR_PIN,        INPUT);
  analogReadResolution(12);

  Wire.begin(SDA_PIN, SCL_PIN);
  MPU6050_Init();

  gsmSerial.begin(GSM_BAUD, SERIAL_8N1, GSM_RX_PIN, GSM_TX_PIN);
  delay(2000);
  GSM_Init();

  // ─── Connect WiFi ─────────────────────────────
  WiFi.begin(ssid, password);
  WiFi.setTxPower(WIFI_POWER_8_5dBm);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Connected! IP: " + WiFi.localIP().toString());

  // ─── Setup MQTT ───────────────────────────────
  client.setServer(mqtt_broker, mqtt_port);
  connectMQTT();

  Serial.println(">> Smart Helmet System Ready!");
  Serial.println(">> Safe     : All axes ≤ ±0.5");
  Serial.println(">> Active   : Any axis ±0.5 to ±10.0");
  Serial.println(">> ACCIDENT : Any axis > ±10.0");
  Serial.println("──────────────────────────────────────");
}

// ════════════════════════════════════════════════
//   LOOP
// ════════════════════════════════════════════════

void loop()
{
  // ─── MQTT Keep-Alive ──────────────────────────
  if (!client.connected()) {
    connectMQTT();
  }
  client.loop();

  // ─── Engine Immobilization Logic ──────────────
  int  alcoholValue = analogRead(ALCOHOL_PIN);
  bool helmetWorn   = (digitalRead(IR_PIN) == LOW);
  bool alcoholSafe  = (alcoholValue < ALCOHOL_THRESHOLD);

  Serial.print("Alcohol: ");
  Serial.print(alcoholValue);
  Serial.print("  |  Helmet: ");
  Serial.println(helmetWorn ? "WORN ✅" : "NOT WORN ❌");

  String command = "";

  if (alcoholSafe && helmetWorn) {
    command = "SAFE";
    Serial.println(">> STATUS: SAFE — Engine ALLOWED ✅");
  } else {
    command = "LOCK";
    if (!alcoholSafe && !helmetWorn) {
      Serial.println(">> STATUS: UNSAFE — Alcohol Detected + Helmet Not Worn! ❌");
    } else if (!alcoholSafe) {
      Serial.println(">> STATUS: UNSAFE — Alcohol Detected! ❌");
    } else if (!helmetWorn) {
      Serial.println(">> STATUS: UNSAFE — Helmet Not Worn! ❌");
    }
  }

  if (command != lastCommand) {
    client.publish(topic, command.c_str());
    Serial.println(">> MQTT Sent: " + command);
    lastCommand = command;
  }

  // ─── Accident Detection Logic ─────────────────
  if (!accidentFired)
  {
    MPU6050_Read_Gyro();

    Serial.println("──────────────────────────────");
    Serial.print("Gyro X: "); Serial.print(gyro_x, 2);
    Serial.print("  Gyro Y: "); Serial.print(gyro_y, 2);
    Serial.print("  Gyro Z: "); Serial.println(gyro_z, 2);

    if (IsAccidentPattern())
    {
      accidentCounter++;
      Serial.print(">> ⚠️  ACCIDENT PATTERN! Count: ");
      Serial.print(accidentCounter);
      Serial.print(" / ");
      Serial.println(CONFIRM_COUNT);

      if (accidentCounter >= CONFIRM_COUNT) {
        HandleImpact();
      }
    }
    else if (IsSafeStationary())
    {
      accidentCounter = 0;
      Serial.println(">> STATUS: Safe Riding ✅");
    }
    else
    {
      accidentCounter = 0;
      Serial.println(">> STATUS: Active Riding ✅");
    }
  }

  delay(500);
}